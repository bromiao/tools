# 项目名称
gdpay静态资源服务

# 项目说明
gdpay静态资源服务 用于存放静态资源 如：图片、视频、音频字体等

# 项目启动
## 1.安装依赖
```
npm install
```
or
```
yarn install
```

## 2.启动项目
```
npm run start
```
or
```
yarn start
```

# 使用方法

## 打开浏览器输入：http://localhost:3002 进入控制台

## 浏览:
1. 里面分为文件夹和文件两种类型
2. 点击文件夹进入文件夹
3. 点击文件打开详情
4. 详情有路径地址+文件名+图片格式

#### 使用方法:
暂时: 使用环境变量
```ts
<img src={`${process.env.REACT_APP_STATIC_PATH}/files/home/1.png`} alt="" />
```
后续优化后会重新定义使用方法

##  上传:

1. 点击上传按钮
2. 跳转到上传页面
3. 选择文件
4. 收入要保存的目录
  ```
  例如：/home/header/
  ```
5. 点击上传
<p style="color: red">注意：文件名不可以不可以中文</p>
<p style="color: red">注意：上传文件的时候，文件名不能重复，否则会覆盖</p>
<p style="color: red">注意：上传文件成功没有提示 注意留意接口</p>
后续会完善....
注意小心使用