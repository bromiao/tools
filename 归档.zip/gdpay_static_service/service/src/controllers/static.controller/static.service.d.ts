interface FileTypes {
    [key: string]: string;
}
interface FileDataList {
    name: string;
    type: 'file' | 'folder';
    files?: FileDataList[];
    path?: FileTypes;
    coords?: Record<string, any>;
}
export declare class StaticService {
    private readonly fileSuffix;
    constructor();
    removeSuffix(data: string[]): string[];
    getFilesByExtension(dir: string, name: string, extensions?: string): FileTypes;
    searchDir(path?: string, sprite?: boolean): FileDataList[];
}
export {};
