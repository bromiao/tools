export declare class StaticModule {
}
