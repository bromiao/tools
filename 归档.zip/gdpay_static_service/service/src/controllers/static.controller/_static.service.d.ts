interface SearchFile {
    name: string;
    path: {
        [key: string]: string;
    };
}
interface FileData {
    name: string;
    path: {
        [key: string]: string;
    };
}
export declare class StaticService {
    private readonly fileSuffix;
    getFilesByExtension(dir: string, extensions: string[]): FileData[];
    searchFiles(path: string, extensions: string[]): {
        name: string;
        path: {
            [extension: string]: string;
        };
    }[];
    searchFile(filename?: string, suffix?: string, type?: string): SearchFile[];
    removeSuffix(data: string[]): string[];
    searchDir(dir?: string): any[];
}
export {};
