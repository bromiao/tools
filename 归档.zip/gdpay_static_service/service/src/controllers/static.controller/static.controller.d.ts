import { StaticService } from './static.service';
interface ImgRes {
    name?: string;
    path?: string;
}
export declare class StaticController {
    private readonly staticService;
    constructor(staticService: StaticService);
    getMimeType(filePath: string): string;
    getImgDir(res: any, reqparam: ImgRes): Promise<any>;
    getSprite(res: any): Promise<void>;
}
export {};
