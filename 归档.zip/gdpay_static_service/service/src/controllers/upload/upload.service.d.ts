import { FileTransferService } from '../file-transfer/file-transfer.service';
export declare class UploadService {
    private readonly fileTransferService;
    constructor(fileTransferService: FileTransferService);
    saveFile(file: any, path?: string, compress?: string, webp?: string): Promise<{
        filename: any;
        path?: undefined;
    } | {
        filename: any;
        path: string;
    }>;
    generateSprite: (path: string) => Promise<unknown>;
    saveFiles(files: any[], path?: string, fileName?: string): Promise<{
        fileName: string;
        cssStrs: string;
        css: {};
        size: any;
        path: string;
        originNames: any[];
    }>;
}
