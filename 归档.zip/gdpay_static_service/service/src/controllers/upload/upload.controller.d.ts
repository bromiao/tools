import { UploadService } from './upload.service';
export declare const editFileName: (req: any, file: any, callback: any) => any;
export declare const imageFileFilter: (req: any, file: any, callback: any) => any;
export declare class UploadController {
    private readonly uploadService;
    constructor(uploadService: UploadService);
    uploadFile(file: any, body: any): Promise<{
        filename: {
            filename: any;
            path?: undefined;
        } | {
            filename: any;
            path: string;
        };
    }>;
    uploadMultipleFiles(files: any[], body: any): Promise<any>;
}
