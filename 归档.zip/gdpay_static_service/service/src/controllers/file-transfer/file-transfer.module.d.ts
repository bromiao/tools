export declare class FileTransferModule {
}
