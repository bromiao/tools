interface ImgInfo {
    dir: string;
    name: string;
    ext: string;
    width: number;
    height: number;
    format: string;
    size: number;
}
export declare class FileTransferService {
    sharp: any;
    getImgInfo(inputPath: string): Promise<ImgInfo>;
    iSharp(inputPath: string, size: number, dir: string): Promise<void>;
    compressImageLoading(inputPath: string, dir: string): Promise<void>;
    generateWebp(inputPath: string, dir: string): Promise<void>;
    compressImage(inputPath: string, compress: boolean, webp: boolean, dir: string): Promise<void>;
}
export {};
