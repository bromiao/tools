export declare class FileTransferController {
}
