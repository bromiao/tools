interface Coords {
    [key: string]: {
        x: number;
        y: number;
        width: number;
        height: number;
    };
}
export declare const transformCoordinates: (coordinates: Coords) => {};
export declare const getcss: (coords: any, width: any, height: any, fileName: any) => {
    cssStrs: string;
    css: {};
};
export {};
