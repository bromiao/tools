/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ([
/* 0 */,
/* 1 */
/***/ ((module) => {

module.exports = require("express");

/***/ }),
/* 2 */
/***/ ((module) => {

module.exports = require("@nestjs/core");

/***/ }),
/* 3 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.AppModule = void 0;
const common_1 = __webpack_require__(4);
const serve_static_1 = __webpack_require__(5);
const path_1 = __webpack_require__(6);
const static_module_1 = __webpack_require__(7);
const file_transfer_module_1 = __webpack_require__(11);
const upload_module_1 = __webpack_require__(15);
const pulicpath = (0, path_1.join)(__dirname, 'public');
let AppModule = exports.AppModule = class AppModule {
};
exports.AppModule = AppModule = __decorate([
    (0, common_1.Module)({
        imports: [
            static_module_1.StaticModule,
            file_transfer_module_1.FileTransferModule,
            upload_module_1.UploadModule,
            serve_static_1.ServeStaticModule.forRoot({
                rootPath: pulicpath,
                serveRoot: '/static',
            }),
        ],
        controllers: [],
        providers: [],
    })
], AppModule);


/***/ }),
/* 4 */
/***/ ((module) => {

module.exports = require("@nestjs/common");

/***/ }),
/* 5 */
/***/ ((module) => {

module.exports = require("@nestjs/serve-static");

/***/ }),
/* 6 */
/***/ ((module) => {

module.exports = require("path");

/***/ }),
/* 7 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.StaticModule = void 0;
const common_1 = __webpack_require__(4);
const static_controller_1 = __webpack_require__(8);
const static_service_1 = __webpack_require__(9);
let StaticModule = exports.StaticModule = class StaticModule {
};
exports.StaticModule = StaticModule = __decorate([
    (0, common_1.Module)({
        imports: [],
        controllers: [static_controller_1.StaticController],
        providers: [static_service_1.StaticService],
    })
], StaticModule);


/***/ }),
/* 8 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.StaticController = void 0;
const common_1 = __webpack_require__(4);
const static_service_1 = __webpack_require__(9);
const path_1 = __webpack_require__(6);
var Searchs;
(function (Searchs) {
    Searchs["img"] = "img";
    Searchs["font"] = "font";
})(Searchs || (Searchs = {}));
let StaticController = exports.StaticController = class StaticController {
    constructor(staticService) {
        this.staticService = staticService;
    }
    getMimeType(filePath) {
        const ext = filePath.split('.').pop().toLowerCase();
        switch (ext) {
            case 'png':
                return 'image/png';
            case 'jpg':
            case 'jpeg':
                return 'image/jpeg';
            case 'gif':
                return 'image/gif';
            case 'svg':
                return 'image/svg+xml';
            case 'ttf':
                return 'font/ttf';
            case 'otf':
                return 'font/otf';
            case 'woff':
                return 'font/woff';
            case 'woff2':
                return 'font/woff2';
            default:
                return 'application/octet-stream';
        }
    }
    async getImgDir(res, reqparam) {
        const data = this.staticService.searchDir(reqparam.path ? reqparam.path : '');
        return res.send({
            code: '0000',
            data,
            msg: '获取成功',
        });
    }
    async getSprite(res) {
        try {
            const data = this.staticService.searchDir((0, path_1.join)(__dirname, 'public/sprites'), true);
            console.log('data', data);
            res.send({
                code: '0000',
                data,
                msg: 'success',
            });
        }
        catch (error) {
            res.send({
                code: '0001',
                data: null,
                msg: error.message ? error.message : 'error',
            });
        }
    }
};
__decorate([
    (0, common_1.Post)('/files/img'),
    __param(0, (0, common_1.Res)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], StaticController.prototype, "getImgDir", null);
__decorate([
    (0, common_1.Post)('/files/sprite'),
    __param(0, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], StaticController.prototype, "getSprite", null);
exports.StaticController = StaticController = __decorate([
    (0, common_1.Controller)(),
    __metadata("design:paramtypes", [static_service_1.StaticService])
], StaticController);


/***/ }),
/* 9 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.StaticService = void 0;
const common_1 = __webpack_require__(4);
const path_1 = __webpack_require__(6);
const fs_1 = __webpack_require__(10);
let StaticService = exports.StaticService = class StaticService {
    constructor() {
        this.fileSuffix = {
            img: ['png', 'jpg', 'gif', 'svg', 'jpeg', 'ico', 'webp', 'bmp', 'avif'],
            font: ['ttf', 'otf', 'woff', 'woff2'],
        };
        if (!(0, fs_1.existsSync)((0, path_1.join)(__dirname, 'public/files'))) {
            (0, fs_1.mkdirSync)((0, path_1.join)(__dirname, 'public/files'));
        }
        if (!(0, fs_1.existsSync)((0, path_1.join)(__dirname, 'public/temp'))) {
            (0, fs_1.mkdirSync)((0, path_1.join)(__dirname, 'public/temp'));
        }
        if (!(0, fs_1.existsSync)((0, path_1.join)(__dirname, 'public/sprites'))) {
            (0, fs_1.mkdirSync)((0, path_1.join)(__dirname, 'public/sprites'));
        }
    }
    removeSuffix(data) {
        const unSuffix = data.map((item) => {
            const nameArr = item.split('.');
            if (nameArr.length > 1)
                nameArr.pop();
            const name = nameArr.join('.');
            if (item.includes('@')) {
                const nameArr = item.split('@');
                if (nameArr.length > 1)
                    nameArr.pop();
                return nameArr.join('@');
            }
            return name;
        });
        const result = new Set([...unSuffix]);
        return [...result];
    }
    getFilesByExtension(dir, name, extensions = 'img') {
        const extens = this.fileSuffix[extensions];
        const result = {};
        for (let i = 0; i < extens.length; i++) {
            const ex = extens[i];
            const filePath = (0, path_1.join)(dir, `${name}.${ex}`);
            if ((0, fs_1.existsSync)(filePath)) {
                result[ex] = filePath.replace((0, path_1.join)(__dirname, 'public'), '');
            }
        }
        return result;
    }
    searchDir(path, sprite = false) {
        const searchPath = path ? path : (0, path_1.join)(__dirname, 'public', 'files');
        const files = (0, fs_1.readdirSync)(searchPath);
        if (files.includes('.DS_Store')) {
            fs_1.promises.unlink((0, path_1.join)(searchPath, '.DS_Store'));
            files.splice(files.indexOf('.DS_Store'), 1);
        }
        const data = this.removeSuffix(files);
        const result = [];
        for (let i = 0; i < data.length; i++) {
            const filePath = this.getFilesByExtension(searchPath, data[i], 'img');
            const fileType = Object.keys(filePath).length > 0 ? 'file' : 'folder';
            const filedata = {
                name: data[i],
                type: fileType,
            };
            if (fileType === 'folder') {
                filedata.files = this.searchDir((0, path_1.join)(searchPath, data[i]), sprite);
            }
            else {
                filedata.path = filePath;
                if (sprite) {
                    const filename = data[i] + '.json';
                    const jsonpath = (0, path_1.join)(searchPath, filename);
                    const exists = (0, fs_1.existsSync)(jsonpath);
                    if (exists) {
                        const json = (0, fs_1.readFileSync)(jsonpath, 'utf-8');
                        const coords = JSON.parse(json);
                        filedata.coords = coords;
                    }
                }
            }
            result.push(filedata);
        }
        result.sort((a, b) => {
            if (a.type === 'folder' && b.type === 'file') {
                return -1;
            }
            else if (a.type === 'file' && b.type === 'folder') {
                return 1;
            }
            else {
                return 0;
            }
        });
        return result;
    }
};
exports.StaticService = StaticService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [])
], StaticService);


/***/ }),
/* 10 */
/***/ ((module) => {

module.exports = require("fs");

/***/ }),
/* 11 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.FileTransferModule = void 0;
const common_1 = __webpack_require__(4);
const file_transfer_controller_1 = __webpack_require__(12);
const file_transfer_service_1 = __webpack_require__(13);
let FileTransferModule = exports.FileTransferModule = class FileTransferModule {
};
exports.FileTransferModule = FileTransferModule = __decorate([
    (0, common_1.Module)({
        controllers: [file_transfer_controller_1.FileTransferController],
        providers: [file_transfer_service_1.FileTransferService],
    })
], FileTransferModule);


/***/ }),
/* 12 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.FileTransferController = void 0;
const common_1 = __webpack_require__(4);
let FileTransferController = exports.FileTransferController = class FileTransferController {
};
exports.FileTransferController = FileTransferController = __decorate([
    (0, common_1.Controller)('file-transfer')
], FileTransferController);


/***/ }),
/* 13 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.FileTransferService = void 0;
const common_1 = __webpack_require__(4);
const path_1 = __webpack_require__(6);
const sharp = __webpack_require__(14);
let FileTransferService = exports.FileTransferService = class FileTransferService {
    async getImgInfo(inputPath) {
        const { dir, name, ext } = (0, path_1.parse)(inputPath);
        const { width, height, format, size } = await sharp(inputPath).metadata();
        return {
            dir,
            name,
            ext,
            width,
            height,
            format,
            size,
        };
    }
    async iSharp(inputPath, size, dir) {
        console.log('dir', dir);
        const { name, ext, width, height } = await this.getImgInfo(inputPath);
        const sizeName = size !== 1 ? '@' + String(size).replace('.', '').padEnd(2, '0') : '';
        const w = Math.ceil(width * size);
        const h = Math.ceil(height * size);
        if (ext === '.png') {
            await sharp(inputPath)
                .resize(w, h)
                .png({ quality: 80 })
                .toFile((0, path_1.join)(dir, `${name + sizeName + ext}`));
        }
        else if (ext === '.jpg') {
            await sharp(inputPath)
                .resize(w, h)
                .jpeg({ quality: 80 })
                .toFile((0, path_1.join)(dir, `${name + sizeName + ext}`));
        }
    }
    async compressImageLoading(inputPath, dir) {
        try {
            const size = [0.2, 0.5, 1];
            const sharps = size.map((item) => {
                return this.iSharp(inputPath, item, dir);
            });
            await Promise.all(sharps);
        }
        catch (error) {
            throw new Error(error);
        }
    }
    async generateWebp(inputPath, dir) {
        try {
            const { name, width, height } = await this.getImgInfo(inputPath);
            console.log('inputPath', inputPath);
            await sharp(inputPath)
                .resize(width, height)
                .webp()
                .toFile((0, path_1.join)(dir, `${name + '.webp'}`));
        }
        catch (error) { }
    }
    async compressImage(inputPath, compress, webp, dir) {
        try {
            console.log('inputPath', inputPath);
            console.log('compress', !!compress);
            console.log('webp', !!webp);
            console.log('1111111', 1111111);
            const { ext } = await this.getImgInfo(inputPath);
            if (ext === '.jpg' || (ext === '.png' && compress)) {
                await this.compressImageLoading(inputPath, dir);
            }
            if (webp)
                await this.generateWebp(inputPath, dir);
            console.log(`压缩图片成功`);
            if (!compress && !webp)
                await this.iSharp(inputPath, 1, dir);
        }
        catch (error) {
            console.log(`压缩图片失败`);
            console.log(error);
        }
    }
};
exports.FileTransferService = FileTransferService = __decorate([
    (0, common_1.Injectable)()
], FileTransferService);


/***/ }),
/* 14 */
/***/ ((module) => {

module.exports = require("sharp");

/***/ }),
/* 15 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.UploadModule = void 0;
const common_1 = __webpack_require__(4);
const upload_service_1 = __webpack_require__(16);
const upload_controller_1 = __webpack_require__(19);
const file_transfer_service_1 = __webpack_require__(13);
let UploadModule = exports.UploadModule = class UploadModule {
};
exports.UploadModule = UploadModule = __decorate([
    (0, common_1.Module)({
        controllers: [upload_controller_1.UploadController],
        providers: [upload_service_1.UploadService, file_transfer_service_1.FileTransferService],
    })
], UploadModule);


/***/ }),
/* 16 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.UploadService = void 0;
const common_1 = __webpack_require__(4);
const path_1 = __webpack_require__(6);
const fs_1 = __webpack_require__(10);
const file_transfer_service_1 = __webpack_require__(13);
const spritesmith = __webpack_require__(17);
const tools_1 = __webpack_require__(18);
let UploadService = exports.UploadService = class UploadService {
    constructor(fileTransferService) {
        this.fileTransferService = fileTransferService;
        this.generateSprite = (path) => new Promise((resolve, reject) => {
            const imageFiles = (0, fs_1.readdirSync)(path).map((file) => (0, path_1.join)(path, file));
            spritesmith.run({
                src: imageFiles,
                algorithm: 'binary-tree',
                padding: 5,
            }, (err, result) => {
                if (err) {
                    console.log('err', err);
                    reject(err);
                }
                else {
                    resolve(result);
                }
            });
        });
    }
    async saveFile(file, path = '', compress, webp) {
        const destinationPath = (0, path_1.join)(__dirname, 'public', 'files', path);
        if (!(0, fs_1.existsSync)(destinationPath)) {
            (0, fs_1.mkdirSync)(destinationPath, { recursive: true });
        }
        const fileName = file.originalname;
        const filePath = (0, path_1.join)(__dirname, 'public', 'temp', fileName);
        if (file.mimetype !== 'image/png' && file.mimetype !== 'image/jpeg') {
            await fs_1.promises.writeFile((0, path_1.join)(destinationPath, fileName), file.buffer);
            return { filename: fileName };
        }
        await fs_1.promises.writeFile(filePath, file.buffer);
        await this.fileTransferService.compressImage(filePath, !!Number(compress), !!Number(webp), destinationPath);
        await fs_1.promises.unlink(filePath);
        return {
            filename: fileName,
            path: (0, path_1.join)('/static', 'files', path, fileName),
        };
    }
    async saveFiles(files, path = '', fileName = 'sprite') {
        try {
            const destinationPath = (0, path_1.join)(__dirname, 'public', 'sprites', path);
            if (!(0, fs_1.existsSync)(destinationPath)) {
                (0, fs_1.mkdirSync)(destinationPath, { recursive: true });
            }
            const fileNames = files.map((file) => file.originalname.split('.').shift());
            const filePaths = files.map((file) => (0, path_1.join)(__dirname, 'public', 'temp', file.originalname));
            const runs = [];
            for (let i = 0; i < files.length; i++) {
                runs.push(fs_1.promises.writeFile(filePaths[i], files[i].buffer));
            }
            await Promise.all(runs);
            const p = (0, path_1.join)(__dirname, 'public', 'temp');
            const { image, properties, coordinates } = (await this.generateSprite(p));
            const coors = (0, tools_1.transformCoordinates)(coordinates);
            const spritePath = (0, path_1.join)(p, `${fileName}.png`);
            await fs_1.promises.writeFile(spritePath, image);
            await this.fileTransferService.compressImage(spritePath, true, true, destinationPath);
            await fs_1.promises.unlink(spritePath);
            const unlinks = [];
            for (let i = 0; i < filePaths.length; i++) {
                unlinks.push(fs_1.promises.unlink(filePaths[i]));
            }
            await Promise.all(unlinks);
            const { cssStrs, css } = (0, tools_1.getcss)(coors, properties.width, properties.height, '/static/sprites' + path + '' + fileName + '.png');
            const json = JSON.stringify(css, null, 2);
            await fs_1.promises.writeFile((0, path_1.join)(destinationPath, `${fileName}.json`), json);
            return {
                fileName,
                cssStrs,
                css,
                size: properties,
                path: '/static/sprites/' + path + '' + fileName + '.png',
                originNames: fileNames,
            };
        }
        catch (error) {
            console.log('error>>>>>', error);
            throw error;
        }
    }
};
exports.UploadService = UploadService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [file_transfer_service_1.FileTransferService])
], UploadService);


/***/ }),
/* 17 */
/***/ ((module) => {

module.exports = require("spritesmith");

/***/ }),
/* 18 */
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getcss = exports.transformCoordinates = void 0;
const transformCoordinates = (coordinates) => {
    const keys = Object.keys(coordinates);
    const newCoordinates = {};
    keys.forEach((key) => {
        const newKey = key.split('/').pop();
        newCoordinates[newKey] = coordinates[key];
    });
    return newCoordinates;
};
exports.transformCoordinates = transformCoordinates;
const getcss = (coords, width, height, fileName) => {
    const keys = Object.keys(coords);
    const css = {};
    const w = width;
    const h = height;
    let cssStrs = `.sprite {\n
    background-image: url('${fileName + '?t=' + Date.now()}');\n
    background-size: ${w}px ${h}px;\n
    background-repeat: no-repeat;\n
  }\n`;
    css['sprite'] = cssStrs;
    keys.forEach((key) => {
        const newKey = key.split('/').pop();
        const { x, y, width, height } = coords[key];
        const c = `
    .sprite-${newKey.split('.').shift()} { \n
      background-position: ${-x}px ${-y}px;\n
      width: ${width}px;\n
      height: ${height}px;\n
    }\n`;
        cssStrs += c;
        css[newKey.split('.').shift()] = c;
    });
    return { cssStrs, css };
};
exports.getcss = getcss;


/***/ }),
/* 19 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.UploadController = exports.imageFileFilter = exports.editFileName = void 0;
const common_1 = __webpack_require__(4);
const upload_service_1 = __webpack_require__(16);
const platform_express_1 = __webpack_require__(20);
const editFileName = (req, file, callback) => {
    console.log('file', file);
    return file.originalname;
};
exports.editFileName = editFileName;
const imageFileFilter = (req, file, callback) => {
    console.log('file', file);
    if (!file.originalname.match(/\.(jpg|jpeg|png|gif)$/)) {
        return callback(new Error('只允许上传图片文件！'), false);
    }
    callback(null, true);
};
exports.imageFileFilter = imageFileFilter;
let UploadController = exports.UploadController = class UploadController {
    constructor(uploadService) {
        this.uploadService = uploadService;
    }
    async uploadFile(file, body) {
        const fileName = await this.uploadService.saveFile(file, body.path, body.compress, body.webp);
        return { filename: fileName };
    }
    async uploadMultipleFiles(files, body) {
        try {
            const path = body.path || '';
            const filename = body.fileName;
            const res = await this.uploadService.saveFiles(files, path, filename);
            return res;
        }
        catch (error) {
            console.log('error', error);
            return error;
        }
    }
};
__decorate([
    (0, common_1.Post)('single'),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file')),
    __param(0, (0, common_1.UploadedFile)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], UploadController.prototype, "uploadFile", null);
__decorate([
    (0, common_1.Post)('multiple'),
    (0, common_1.UseInterceptors)((0, platform_express_1.FilesInterceptor)('files')),
    __param(0, (0, common_1.UploadedFiles)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Array, Object]),
    __metadata("design:returntype", Promise)
], UploadController.prototype, "uploadMultipleFiles", null);
exports.UploadController = UploadController = __decorate([
    (0, common_1.Controller)('upload'),
    __metadata("design:paramtypes", [upload_service_1.UploadService])
], UploadController);


/***/ }),
/* 20 */
/***/ ((module) => {

module.exports = require("@nestjs/platform-express");

/***/ })
/******/ 	]);
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be isolated against other modules in the chunk.
(() => {
var exports = __webpack_exports__;

Object.defineProperty(exports, "__esModule", ({ value: true }));
const express = __webpack_require__(1);
const core_1 = __webpack_require__(2);
const app_module_1 = __webpack_require__(3);
async function bootstrap() {
    const app = await core_1.NestFactory.create(app_module_1.AppModule);
    app.use(express.json());
    app.use(express.urlencoded({ extended: true }));
    app.enableCors({
        origin: true,
        methods: 'GET,HEAD,PUT,PATCH,POST,DELETE',
        allowedHeaders: '*',
        preflightContinue: false,
        optionsSuccessStatus: 200,
    });
    await app.listen(3003);
}
bootstrap();

})();

/******/ })()
;