module.exports = {
  '*.{js,jsx,ts,tsx,cjs}': ['eslint --fix', 'prettier --write'],
  '{!(package)*.json,.!(browserslist)*rc}': ['prettier --write--parser json'],
  'package.json': ['prettier --write'],
  '*.vue': ['eslint --fix', 'prettier --write'],
  '*.{vue,css,scss,postcss,less}': ['prettier --write'],
  '*.md': ['prettier --write'],
}
