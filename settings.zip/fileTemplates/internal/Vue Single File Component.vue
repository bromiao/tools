<template>
  <div>

  </div>
</template>

<script>
  export default {
    name: "${NAME}"
  }
</script>

<style scoped lang="scss">

</style>