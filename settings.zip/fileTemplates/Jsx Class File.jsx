import React from 'react'
    
export default class ${NAME} extends React.Component {
    constructor() {
        super();
    }
    
    render() {
        return (
            <div>
            
            </div>
        )
    }
}